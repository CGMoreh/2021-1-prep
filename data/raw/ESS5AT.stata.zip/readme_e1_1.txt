Version notes 

ESS5 Main data, Austria, edition 1.1 (published 09.02.17):
Changes from edition 1.0:

Changes in data:
Variable pspwght "Post-stratification weight including design weight" has been added.